# 🚢 TITANIC SURVIVAL PREDICTION

This project applies a machine learning workflow to the classic Titanic dataset to predict whether a passenger survived or not. It serves as an introductory portfolio piece showcasing skills in data cleaning, feature engineering, and binary classification using Python and scikit-learn.

### 🎯 Project Goal

The objective was to build a robust classification model that predicts the binary outcome (`Survived`: 0 = No, 1 = Yes) based on passenger features such as age, gender, ticket class, and fare.

***

## 📈 Model Performance & Key Findings

| Metric | Result |
| :--- | :--- |
| **Model** | Random Forest Classifier |
| **Accuracy on Test Set** | **82.68%** |

### Feature Importance Analysis

The model revealed clear drivers for survival prediction, ranked by importance. This insight demonstrates which passenger characteristics were most critical:

1.  **Sex** (Dominant factor): Reflecting the "women and children first" protocol.
2.  **Fare**: Higher fares (generally indicating 1st/2nd class) positively correlated with survival.
3.  **Pclass\_3**: Being in third class was a major negative predictor.
4.  **Age**: Important for identifying higher survival rates among children.
5.  **FamilySize**: The total number of family members (SibSp + Parch + 1).

***

## ⚙️ Repository Contents

| File | Description |
| :--- | :--- |
| **`titanic_predictor.py`** | The main Python script containing data preprocessing, feature engineering (e.g., creating `FamilySize`), model training (Random Forest), and evaluation. |
| **`Titanic-Dataset.csv`** | The raw dataset used for this analysis. |
| **`requirements.txt`** | A list of all necessary Python libraries (`pandas`, `scikit-learn`, `numpy`) for replicating the environment. |
| **`README.md`** | This documentation file, which provides the project overview and results. |

***

## 🚀 How to Run This Project

To replicate these results locally, follow these steps:

1.  **Clone the Repository:**
    ```bash
    git clone [YOUR_REPO_LINK]
    cd Titanic-Survival-Prediction
    ```
2.  **Install Dependencies:**
    ```bash
    pip install -r requirements.txt
    ```
3.  **Execute the Script:**
    ```bash
    python titanic_predictor.py
    ```