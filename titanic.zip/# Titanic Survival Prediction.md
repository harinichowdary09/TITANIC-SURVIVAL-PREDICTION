# Titanic Survival Prediction

Small project demonstrating a Random Forest classifier for predicting passenger survival on the Titanic dataset.

## Summary

- Model: Random Forest
- Test Accuracy: **82.68%**
- Most important features:
    1. Sex
    2. Fare
    3. Pclass_3

## Files (example)

- `data/` - raw and processed datasets (train/test)
- `notebooks/` - exploratory analysis and EDA notebooks
- `src/` - training, evaluation and utility scripts
    - `train.py` - trains the model and saves artifacts
    - `evaluate.py` - runs evaluation on test set and prints metrics
    - `predict.py` - inference on new samples
- `requirements.txt` - pinned Python dependencies
- `README.md` - this file

## Requirements

- Python 3.8+
- Recommended packages (example):
    - pandas, numpy, scikit-learn, matplotlib, seaborn, joblib

Install:
# --- 5. Prediction and Evaluation ---
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

# NOTE: The resulting accuracy for this model setup is typically around 0.82-0.83.
print("-" * 50)
print("TITANIC SURVIVAL PREDICTION RESULTS")
print("-" * 50)
print(f"Model: Random Forest Classifier")
print(f"Accuracy on the test set: {accuracy:.4f}")